<script src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/assets/js/language.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.validate.min.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/assets/js/common.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/assets/js/wow.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/bottom_service.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/assets/js/owl.carousel.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.fancybox-1.3.4.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/cloud-zoom.1.0.3.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.cookie.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/assets/js/skrollr.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/custom_service.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/assets/js/swiper.min.js"></script>
<script type="text/javascript">
    var swiper = new Swiper('.swiper-container', {
        pagination: {
            el: '.swiper-pagination',
        },
        autoplay: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
</script>

<script>
    //侧边栏展开/收缩
    $('.side-cate>li ul').css('display', 'none')
</script>